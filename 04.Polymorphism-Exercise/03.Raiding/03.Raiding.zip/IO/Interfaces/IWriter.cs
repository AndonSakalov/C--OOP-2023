﻿namespace _03.Raiding.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(object obj);
    }
}
